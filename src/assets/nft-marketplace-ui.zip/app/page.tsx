"use client"

import { useState } from "react"
import { SidebarProvider } from "@/components/ui/sidebar"
import { MarketplaceSidebar } from "@/components/marketplace-sidebar"
import { MarketplaceHeader } from "@/components/marketplace-header"
import { NFTGrid } from "@/components/nft-grid"
import { AgentPanel } from "@/components/agent-panel"
import { SwarmModePanel } from "@/components/swarm-mode-panel"

export default function NFTMarketplace() {
  const [selectedNFT, setSelectedNFT] = useState<any>(null)
  const [filters, setFilters] = useState({
    blockchain: "all",
    priceRange: [0, 1000],
    availability: "all",
    collection: "",
    rarity: "all",
  })

  return (
    <div className="min-h-screen bg-gray-50">
      <MarketplaceHeader />

      <SidebarProvider defaultOpen={true}>
        <div className="flex">
          <MarketplaceSidebar filters={filters} setFilters={setFilters} />

          <main className="flex-1 p-6">
            <div className="grid grid-cols-1 xl:grid-cols-4 gap-6">
              {/* Main NFT Grid - Takes up 3 columns */}
              <div className="xl:col-span-3">
                <NFTGrid filters={filters} onSelectNFT={setSelectedNFT} selectedNFT={selectedNFT} />
              </div>

              {/* Right Panel - AI Agent & Swarm Mode */}
              <div className="xl:col-span-1 space-y-6">
                <AgentPanel selectedNFT={selectedNFT} />
                <SwarmModePanel />
              </div>
            </div>
          </main>
        </div>
      </SidebarProvider>
    </div>
  )
}
