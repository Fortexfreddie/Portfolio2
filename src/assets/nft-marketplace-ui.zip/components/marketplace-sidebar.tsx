"use client"

import { useState } from "react"
import { ChevronDown, Filter, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { Slider } from "@/components/ui/slider"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"

interface MarketplaceSidebarProps {
  filters: any
  setFilters: (filters: any) => void
}

export function MarketplaceSidebar({ filters, setFilters }: MarketplaceSidebarProps) {
  const [openSections, setOpenSections] = useState({
    blockchain: true,
    availability: true,
    price: true,
    collections: true,
    rarity: true,
    traits: false,
  })

  const blockchains = [
    { id: "ethereum", name: "Ethereum", icon: "⟠", count: 1234 },
    { id: "polygon", name: "Polygon", icon: "⬟", count: 567 },
    { id: "bnb", name: "BNB Chain", icon: "◆", count: 890 },
    { id: "pi", name: "Pi Network", icon: "π", count: 234 },
  ]

  const collections = [
    { id: "bayc", name: "Bored Ape Yacht Club", icon: "🐵", floor: 45.2 },
    { id: "cryptopunks", name: "CryptoPunks", icon: "👾", floor: 67.8 },
    { id: "azuki", name: "Azuki", icon: "🌸", floor: 12.3 },
    { id: "doodles", name: "Doodles", icon: "🎨", floor: 8.9 },
  ]

  const toggleSection = (section: string) => {
    setOpenSections((prev) => ({ ...prev, [section]: !prev[section] }))
  }

  return (
    <div className="w-80 bg-white border-r border-gray-200 h-[calc(100vh-73px)] overflow-y-auto">
      <div className="p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-lg font-semibold flex items-center">
            <Filter className="w-5 h-5 mr-2" />
            Filters
          </h2>
          <Button variant="ghost" size="sm" className="text-gray-500">
            Clear all
          </Button>
        </div>

        {/* Active Filters */}
        <div className="flex flex-wrap gap-2 mb-6">
          <Badge variant="secondary" className="flex items-center gap-1">
            All Chains
            <X className="w-3 h-3 cursor-pointer" />
          </Badge>
          <Badge variant="secondary" className="flex items-center gap-1">
            On Sale
            <X className="w-3 h-3 cursor-pointer" />
          </Badge>
        </div>

        <div className="space-y-6">
          {/* Blockchain Filter */}
          <Collapsible open={openSections.blockchain} onOpenChange={() => toggleSection("blockchain")}>
            <CollapsibleTrigger className="flex items-center justify-between w-full p-0">
              <h3 className="font-medium">Blockchain</h3>
              <ChevronDown className={`w-4 h-4 transition-transform ${openSections.blockchain ? "rotate-180" : ""}`} />
            </CollapsibleTrigger>
            <CollapsibleContent className="space-y-3 mt-3">
              {blockchains.map((blockchain) => (
                <div key={blockchain.id} className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <Checkbox id={blockchain.id} />
                    <label htmlFor={blockchain.id} className="flex items-center space-x-2 cursor-pointer">
                      <span className="text-lg">{blockchain.icon}</span>
                      <span className="text-sm">{blockchain.name}</span>
                    </label>
                  </div>
                  <span className="text-xs text-gray-500">{blockchain.count}</span>
                </div>
              ))}
            </CollapsibleContent>
          </Collapsible>

          <Separator />

          {/* Availability Filter */}
          <Collapsible open={openSections.availability} onOpenChange={() => toggleSection("availability")}>
            <CollapsibleTrigger className="flex items-center justify-between w-full p-0">
              <h3 className="font-medium">Availability</h3>
              <ChevronDown
                className={`w-4 h-4 transition-transform ${openSections.availability ? "rotate-180" : ""}`}
              />
            </CollapsibleTrigger>
            <CollapsibleContent className="space-y-3 mt-3">
              <div className="flex items-center space-x-3">
                <Checkbox id="all" defaultChecked />
                <label htmlFor="all" className="text-sm cursor-pointer">
                  All
                </label>
              </div>
              <div className="flex items-center space-x-3">
                <Checkbox id="on-sale" />
                <label htmlFor="on-sale" className="text-sm cursor-pointer">
                  On Sale
                </label>
              </div>
              <div className="flex items-center space-x-3">
                <Checkbox id="auction" />
                <label htmlFor="auction" className="text-sm cursor-pointer">
                  Auction
                </label>
              </div>
              <div className="flex items-center space-x-3">
                <Checkbox id="new-listing" />
                <label htmlFor="new-listing" className="text-sm cursor-pointer">
                  New Listings
                </label>
              </div>
            </CollapsibleContent>
          </Collapsible>

          <Separator />

          {/* Price Range */}
          <Collapsible open={openSections.price} onOpenChange={() => toggleSection("price")}>
            <CollapsibleTrigger className="flex items-center justify-between w-full p-0">
              <h3 className="font-medium">Price Range</h3>
              <ChevronDown className={`w-4 h-4 transition-transform ${openSections.price ? "rotate-180" : ""}`} />
            </CollapsibleTrigger>
            <CollapsibleContent className="mt-4">
              <div className="space-y-4">
                <Slider defaultValue={[0, 100]} max={100} step={1} className="w-full" />
                <div className="flex items-center justify-between text-sm text-gray-500">
                  <span>0 ETH</span>
                  <span>100+ ETH</span>
                </div>
              </div>
            </CollapsibleContent>
          </Collapsible>

          <Separator />

          {/* Collections */}
          <Collapsible open={openSections.collections} onOpenChange={() => toggleSection("collections")}>
            <CollapsibleTrigger className="flex items-center justify-between w-full p-0">
              <h3 className="font-medium">Collections</h3>
              <ChevronDown className={`w-4 h-4 transition-transform ${openSections.collections ? "rotate-180" : ""}`} />
            </CollapsibleTrigger>
            <CollapsibleContent className="space-y-3 mt-3">
              {collections.map((collection) => (
                <div key={collection.id} className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <Checkbox id={collection.id} />
                    <label htmlFor={collection.id} className="flex items-center space-x-2 cursor-pointer">
                      <span className="text-lg">{collection.icon}</span>
                      <div>
                        <div className="text-sm font-medium">{collection.name}</div>
                        <div className="text-xs text-gray-500">Floor: {collection.floor} ETH</div>
                      </div>
                    </label>
                  </div>
                </div>
              ))}
            </CollapsibleContent>
          </Collapsible>

          <Separator />

          {/* Rarity */}
          <Collapsible open={openSections.rarity} onOpenChange={() => toggleSection("rarity")}>
            <CollapsibleTrigger className="flex items-center justify-between w-full p-0">
              <h3 className="font-medium">Rarity</h3>
              <ChevronDown className={`w-4 h-4 transition-transform ${openSections.rarity ? "rotate-180" : ""}`} />
            </CollapsibleTrigger>
            <CollapsibleContent className="space-y-3 mt-3">
              <div className="flex items-center space-x-3">
                <Checkbox id="legendary" />
                <label htmlFor="legendary" className="text-sm cursor-pointer flex items-center">
                  <span className="w-3 h-3 bg-yellow-400 rounded-full mr-2"></span>
                  Legendary (0.1%)
                </label>
              </div>
              <div className="flex items-center space-x-3">
                <Checkbox id="epic" />
                <label htmlFor="epic" className="text-sm cursor-pointer flex items-center">
                  <span className="w-3 h-3 bg-purple-400 rounded-full mr-2"></span>
                  Epic (1%)
                </label>
              </div>
              <div className="flex items-center space-x-3">
                <Checkbox id="rare" />
                <label htmlFor="rare" className="text-sm cursor-pointer flex items-center">
                  <span className="w-3 h-3 bg-blue-400 rounded-full mr-2"></span>
                  Rare (5%)
                </label>
              </div>
              <div className="flex items-center space-x-3">
                <Checkbox id="common" />
                <label htmlFor="common" className="text-sm cursor-pointer flex items-center">
                  <span className="w-3 h-3 bg-gray-400 rounded-full mr-2"></span>
                  Common (93.9%)
                </label>
              </div>
            </CollapsibleContent>
          </Collapsible>
        </div>
      </div>
    </div>
  )
}
