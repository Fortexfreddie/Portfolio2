"use client"

import { useState } from "react"
import { Grid, List, Eye, Heart, Flag, TrendingUp } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface NFTGridProps {
  filters: any
  onSelectNFT: (nft: any) => void
  selectedNFT: any
}

export function NFTGrid({ filters, onSelectNFT, selectedNFT }: NFTGridProps) {
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid")
  const [sortBy, setSortBy] = useState("recently-listed")

  const mockNFTs = [
    {
      id: 1,
      name: "Cosmic Warrior #1234",
      collection: "Cosmic Warriors",
      image: "/placeholder.svg?height=300&width=300",
      price: 2.5,
      currency: "ETH",
      estimatedValue: 3.2,
      rarity: "Epic",
      rarityScore: 8.7,
      owner: "0x1234...5678",
      isVerified: true,
      isSuspicious: false,
      isUndervalued: true,
      views: 1234,
      likes: 89,
      chain: "ethereum",
    },
    {
      id: 2,
      name: "Digital Dreams #0567",
      collection: "Digital Dreams",
      image: "/placeholder.svg?height=300&width=300",
      price: 0.8,
      currency: "ETH",
      estimatedValue: 0.9,
      rarity: "Rare",
      rarityScore: 6.3,
      owner: "0x5678...9012",
      isVerified: true,
      isSuspicious: false,
      isUndervalued: false,
      views: 567,
      likes: 34,
      chain: "ethereum",
    },
    {
      id: 3,
      name: "Pi Punk #2345",
      collection: "Pi Punks",
      image: "/placeholder.svg?height=300&width=300",
      price: 150,
      currency: "PI",
      estimatedValue: 180,
      rarity: "Legendary",
      rarityScore: 9.8,
      owner: "0x9012...3456",
      isVerified: false,
      isSuspicious: false,
      isUndervalued: true,
      views: 2345,
      likes: 156,
      chain: "pi",
    },
    {
      id: 4,
      name: "Cyber Cat #0789",
      collection: "Cyber Cats",
      image: "/placeholder.svg?height=300&width=300",
      price: 1.2,
      currency: "ETH",
      estimatedValue: 1.1,
      rarity: "Common",
      rarityScore: 3.2,
      owner: "0x3456...7890",
      isVerified: true,
      isSuspicious: true,
      isUndervalued: false,
      views: 789,
      likes: 23,
      chain: "polygon",
    },
    {
      id: 5,
      name: "Quantum Sphere #1111",
      collection: "Quantum Art",
      image: "/placeholder.svg?height=300&width=300",
      price: 4.7,
      currency: "ETH",
      estimatedValue: 5.2,
      rarity: "Epic",
      rarityScore: 8.1,
      owner: "0x7890...1234",
      isVerified: true,
      isSuspicious: false,
      isUndervalued: true,
      views: 1567,
      likes: 98,
      chain: "ethereum",
    },
    {
      id: 6,
      name: "Neon Genesis #0404",
      collection: "Neon Genesis",
      image: "/placeholder.svg?height=300&width=300",
      price: 0.3,
      currency: "BNB",
      estimatedValue: 0.35,
      rarity: "Rare",
      rarityScore: 7.4,
      owner: "0x1111...2222",
      isVerified: true,
      isSuspicious: false,
      isUndervalued: false,
      views: 445,
      likes: 67,
      chain: "bnb",
    },
  ]

  const getRarityColor = (rarity: string) => {
    switch (rarity) {
      case "Legendary":
        return "bg-yellow-100 text-yellow-800 border-yellow-200"
      case "Epic":
        return "bg-purple-100 text-purple-800 border-purple-200"
      case "Rare":
        return "bg-blue-100 text-blue-800 border-blue-200"
      default:
        return "bg-gray-100 text-gray-800 border-gray-200"
    }
  }

  const getChainIcon = (chain: string) => {
    switch (chain) {
      case "ethereum":
        return "⟠"
      case "polygon":
        return "⬟"
      case "bnb":
        return "◆"
      case "pi":
        return "π"
      default:
        return "⟠"
    }
  }

  return (
    <div className="space-y-6">
      {/* Header Controls */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <h1 className="text-2xl font-bold">Explore NFTs</h1>
          <Badge variant="secondary" className="text-sm">
            {mockNFTs.length} items
          </Badge>
        </div>

        <div className="flex items-center space-x-4">
          <Select value={sortBy} onValueChange={setSortBy}>
            <SelectTrigger className="w-48">
              <SelectValue placeholder="Sort by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="recently-listed">Recently Listed</SelectItem>
              <SelectItem value="price-low-high">Price: Low to High</SelectItem>
              <SelectItem value="price-high-low">Price: High to Low</SelectItem>
              <SelectItem value="rarity-score">Rarity Score</SelectItem>
              <SelectItem value="ai-estimated">AI Estimated Value</SelectItem>
              <SelectItem value="most-viewed">Most Viewed</SelectItem>
            </SelectContent>
          </Select>

          <div className="flex items-center border rounded-lg">
            <Button
              variant={viewMode === "grid" ? "default" : "ghost"}
              size="sm"
              onClick={() => setViewMode("grid")}
              className="rounded-r-none"
            >
              <Grid className="w-4 h-4" />
            </Button>
            <Button
              variant={viewMode === "list" ? "default" : "ghost"}
              size="sm"
              onClick={() => setViewMode("list")}
              className="rounded-l-none"
            >
              <List className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* NFT Grid */}
      <div className={viewMode === "grid" ? "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" : "space-y-4"}>
        {mockNFTs.map((nft) => (
          <Card
            key={nft.id}
            className={`group cursor-pointer transition-all duration-200 hover:shadow-lg ${
              selectedNFT?.id === nft.id ? "ring-2 ring-blue-500" : ""
            }`}
            onClick={() => onSelectNFT(nft)}
          >
            <CardContent className="p-0">
              {viewMode === "grid" ? (
                <div className="space-y-4">
                  {/* Image */}
                  <div className="relative overflow-hidden rounded-t-lg">
                    <img
                      src={nft.image || "/placeholder.svg"}
                      alt={nft.name}
                      className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-200"
                    />

                    {/* Overlay badges */}
                    <div className="absolute top-3 left-3 flex flex-wrap gap-2">
                      <Badge className={getRarityColor(nft.rarity)}>{nft.rarity}</Badge>
                      {nft.isUndervalued && (
                        <Badge className="bg-green-100 text-green-800 border-green-200 flex items-center gap-1">
                          <TrendingUp className="w-3 h-3" />
                          Undervalued
                        </Badge>
                      )}
                    </div>

                    <div className="absolute top-3 right-3 flex flex-col gap-2">
                      <Badge variant="secondary" className="text-xs">
                        {getChainIcon(nft.chain)}
                      </Badge>
                      {nft.isSuspicious && (
                        <Badge variant="destructive" className="text-xs">
                          <Flag className="w-3 h-3" />
                        </Badge>
                      )}
                    </div>

                    {/* Action buttons on hover */}
                    <div className="absolute bottom-3 right-3 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <Button size="sm" variant="secondary" className="h-8 w-8 p-0">
                        <Heart className="w-4 h-4" />
                      </Button>
                      <Button size="sm" variant="secondary" className="h-8 w-8 p-0">
                        <Eye className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>

                  {/* Content */}
                  <div className="p-4 space-y-3">
                    <div>
                      <h3 className="font-semibold text-lg truncate">{nft.name}</h3>
                      <p className="text-sm text-gray-600 flex items-center gap-1">
                        {nft.collection}
                        {nft.isVerified && (
                          <Badge variant="secondary" className="text-xs">
                            ✓
                          </Badge>
                        )}
                      </p>
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-gray-500">Price</p>
                        <p className="font-bold text-lg">
                          {nft.price} {nft.currency}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm text-gray-500">AI Est.</p>
                        <p className="font-medium text-green-600">
                          {nft.estimatedValue} {nft.currency}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center justify-between text-sm text-gray-500">
                      <span>Rarity: {nft.rarityScore}/10</span>
                      <div className="flex items-center gap-3">
                        <span className="flex items-center gap-1">
                          <Eye className="w-3 h-3" />
                          {nft.views}
                        </span>
                        <span className="flex items-center gap-1">
                          <Heart className="w-3 h-3" />
                          {nft.likes}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                // List view layout
                <div className="flex items-center p-4 space-x-4">
                  <img
                    src={nft.image || "/placeholder.svg"}
                    alt={nft.name}
                    className="w-16 h-16 object-cover rounded-lg"
                  />
                  <div className="flex-1 grid grid-cols-6 gap-4 items-center">
                    <div className="col-span-2">
                      <h3 className="font-semibold">{nft.name}</h3>
                      <p className="text-sm text-gray-600">{nft.collection}</p>
                    </div>
                    <div>
                      <Badge className={getRarityColor(nft.rarity)}>{nft.rarity}</Badge>
                    </div>
                    <div className="text-center">
                      <p className="font-bold">
                        {nft.price} {nft.currency}
                      </p>
                    </div>
                    <div className="text-center">
                      <p className="text-green-600 font-medium">
                        {nft.estimatedValue} {nft.currency}
                      </p>
                    </div>
                    <div className="flex justify-end gap-2">
                      <Button size="sm" variant="outline">
                        View
                      </Button>
                      <Button size="sm">Buy Now</Button>
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
