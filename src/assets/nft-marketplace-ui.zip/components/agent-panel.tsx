"use client"

import { useState } from "react"
import { Bot, TrendingUp, AlertTriangle, Zap, Target, Brain } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Separator } from "@/components/ui/separator"

interface AgentPanelProps {
  selectedNFT: any
}

export function AgentPanel({ selectedNFT }: AgentPanelProps) {
  const [isAnalyzing, setIsAnalyzing] = useState(false)

  const runAnalysis = () => {
    setIsAnalyzing(true)
    setTimeout(() => setIsAnalyzing(false), 2000)
  }

  const agentInsights = {
    recommendation: "BUY",
    confidence: 87,
    priceTarget: 3.8,
    riskLevel: "Medium",
    marketSentiment: "Bullish",
    volumeSpike: true,
    rarityRank: 234,
    totalSupply: 10000,
  }

  return (
    <Card className="h-fit">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-lg">
          <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-500 rounded-lg flex items-center justify-center">
            <Bot className="w-4 h-4 text-white" />
          </div>
          AI Agent Analysis
        </CardTitle>
      </CardHeader>

      <CardContent className="space-y-4">
        {!selectedNFT ? (
          <div className="text-center py-8 text-gray-500">
            <Brain className="w-12 h-12 mx-auto mb-3 opacity-50" />
            <p className="text-sm">Select an NFT to get AI-powered insights</p>
          </div>
        ) : (
          <>
            {/* Selected NFT Info */}
            <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
              <img
                src={selectedNFT.image || "/placeholder.svg"}
                alt={selectedNFT.name}
                className="w-12 h-12 object-cover rounded-lg"
              />
              <div className="flex-1 min-w-0">
                <h4 className="font-medium truncate">{selectedNFT.name}</h4>
                <p className="text-sm text-gray-600">{selectedNFT.collection}</p>
              </div>
            </div>

            {/* Analysis Button */}
            <Button onClick={runAnalysis} disabled={isAnalyzing} className="w-full">
              {isAnalyzing ? (
                <>
                  <Zap className="w-4 h-4 mr-2 animate-pulse" />
                  Analyzing...
                </>
              ) : (
                <>
                  <Brain className="w-4 h-4 mr-2" />
                  Run AI Analysis
                </>
              )}
            </Button>

            <Separator />

            {/* AI Recommendations */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Recommendation</span>
                <Badge
                  className={
                    agentInsights.recommendation === "BUY"
                      ? "bg-green-100 text-green-800 border-green-200"
                      : agentInsights.recommendation === "SELL"
                        ? "bg-red-100 text-red-800 border-red-200"
                        : "bg-yellow-100 text-yellow-800 border-yellow-200"
                  }
                >
                  {agentInsights.recommendation}
                </Badge>
              </div>

              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium">Confidence</span>
                  <span className="text-sm text-gray-600">{agentInsights.confidence}%</span>
                </div>
                <Progress value={agentInsights.confidence} className="h-2" />
              </div>

              <div className="grid grid-cols-2 gap-3 text-sm">
                <div>
                  <p className="text-gray-600">Price Target</p>
                  <p className="font-semibold text-green-600">{agentInsights.priceTarget} ETH</p>
                </div>
                <div>
                  <p className="text-gray-600">Risk Level</p>
                  <p className="font-semibold">{agentInsights.riskLevel}</p>
                </div>
              </div>

              <Separator />

              {/* Market Insights */}
              <div className="space-y-3">
                <h4 className="font-medium text-sm">Market Insights</h4>

                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-600">Sentiment</span>
                  <div className="flex items-center gap-1">
                    <TrendingUp className="w-4 h-4 text-green-500" />
                    <span className="text-green-600">{agentInsights.marketSentiment}</span>
                  </div>
                </div>

                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-600">Volume Spike</span>
                  <Badge variant={agentInsights.volumeSpike ? "default" : "secondary"}>
                    {agentInsights.volumeSpike ? "Yes" : "No"}
                  </Badge>
                </div>

                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-600">Rarity Rank</span>
                  <span className="font-medium">
                    #{agentInsights.rarityRank} / {agentInsights.totalSupply}
                  </span>
                </div>
              </div>

              <Separator />

              {/* Quick Actions */}
              <div className="space-y-2">
                <h4 className="font-medium text-sm">Quick Actions</h4>
                <div className="grid grid-cols-2 gap-2">
                  <Button size="sm" variant="outline" className="text-xs bg-transparent">
                    <Target className="w-3 h-3 mr-1" />
                    Set Alert
                  </Button>
                  <Button size="sm" variant="outline" className="text-xs bg-transparent">
                    <TrendingUp className="w-3 h-3 mr-1" />
                    Track Price
                  </Button>
                </div>
              </div>

              {/* Risk Warning */}
              {selectedNFT?.isSuspicious && (
                <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
                  <div className="flex items-center gap-2 text-red-800">
                    <AlertTriangle className="w-4 h-4" />
                    <span className="text-sm font-medium">Risk Alert</span>
                  </div>
                  <p className="text-xs text-red-700 mt-1">
                    This NFT has been flagged for suspicious activity. Exercise caution.
                  </p>
                </div>
              )}
            </div>
          </>
        )}
      </CardContent>
    </Card>
  )
}
