import { Activity, Users, Zap, TrendingUp, Eye } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"

export function SwarmModePanel() {
  const swarmData = {
    activeAgents: 47,
    totalScans: 12847,
    trendsDetected: 8,
    volumeSpikes: 3,
    newOpportunities: 5,
  }

  const recentActivity = [
    {
      type: "volume_spike",
      collection: "Cosmic Warriors",
      change: "+340%",
      time: "2m ago",
    },
    {
      type: "new_mint",
      collection: "Digital Dreams",
      count: 150,
      time: "5m ago",
    },
    {
      type: "price_drop",
      collection: "Cyber Cats",
      change: "-15%",
      time: "8m ago",
    },
    {
      type: "whale_activity",
      collection: "Pi Punks",
      amount: "50 ETH",
      time: "12m ago",
    },
  ]

  const getActivityIcon = (type: string) => {
    switch (type) {
      case "volume_spike":
        return <TrendingUp className="w-4 h-4 text-green-500" />
      case "new_mint":
        return <Zap className="w-4 h-4 text-blue-500" />
      case "price_drop":
        return <TrendingUp className="w-4 h-4 text-red-500 rotate-180" />
      case "whale_activity":
        return <Users className="w-4 h-4 text-purple-500" />
      default:
        return <Activity className="w-4 h-4 text-gray-500" />
    }
  }

  const getActivityColor = (type: string) => {
    switch (type) {
      case "volume_spike":
        return "text-green-600"
      case "new_mint":
        return "text-blue-600"
      case "price_drop":
        return "text-red-600"
      case "whale_activity":
        return "text-purple-600"
      default:
        return "text-gray-600"
    }
  }

  return (
    <Card className="h-fit">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-lg">
          <div className="w-8 h-8 bg-gradient-to-r from-green-500 to-blue-500 rounded-lg flex items-center justify-center">
            <Activity className="w-4 h-4 text-white" />
          </div>
          Swarm Intelligence
        </CardTitle>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Swarm Stats */}
        <div className="grid grid-cols-2 gap-3">
          <div className="text-center p-3 bg-gray-50 rounded-lg">
            <div className="text-2xl font-bold text-blue-600">{swarmData.activeAgents}</div>
            <div className="text-xs text-gray-600">Active Agents</div>
          </div>
          <div className="text-center p-3 bg-gray-50 rounded-lg">
            <div className="text-2xl font-bold text-green-600">{swarmData.totalScans.toLocaleString()}</div>
            <div className="text-xs text-gray-600">Total Scans</div>
          </div>
        </div>

        {/* Detection Stats */}
        <div className="space-y-3">
          <div className="flex items-center justify-between text-sm">
            <span className="text-gray-600">Trends Detected</span>
            <Badge variant="secondary">{swarmData.trendsDetected}</Badge>
          </div>
          <div className="flex items-center justify-between text-sm">
            <span className="text-gray-600">Volume Spikes</span>
            <Badge className="bg-orange-100 text-orange-800 border-orange-200">{swarmData.volumeSpikes}</Badge>
          </div>
          <div className="flex items-center justify-between text-sm">
            <span className="text-gray-600">New Opportunities</span>
            <Badge className="bg-green-100 text-green-800 border-green-200">{swarmData.newOpportunities}</Badge>
          </div>
        </div>

        {/* Activity Feed */}
        <div className="space-y-3">
          <h4 className="font-medium text-sm flex items-center gap-2">
            <Eye className="w-4 h-4" />
            Live Activity
          </h4>

          <div className="space-y-2 max-h-48 overflow-y-auto">
            {recentActivity.map((activity, index) => (
              <div key={index} className="flex items-center gap-3 p-2 bg-gray-50 rounded-lg text-sm">
                {getActivityIcon(activity.type)}
                <div className="flex-1 min-w-0">
                  <div className="font-medium truncate">{activity.collection}</div>
                  <div className={`text-xs ${getActivityColor(activity.type)}`}>
                    {activity.type === "volume_spike" && `Volume ${activity.change}`}
                    {activity.type === "new_mint" && `${activity.count} new mints`}
                    {activity.type === "price_drop" && `Floor ${activity.change}`}
                    {activity.type === "whale_activity" && `${activity.amount} purchase`}
                  </div>
                </div>
                <div className="text-xs text-gray-500">{activity.time}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Swarm Health */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span className="text-gray-600">Swarm Health</span>
            <span className="text-green-600 font-medium">Optimal</span>
          </div>
          <Progress value={94} className="h-2" />
          <div className="text-xs text-gray-500">94% of agents reporting normally</div>
        </div>
      </CardContent>
    </Card>
  )
}
