import { Search, Bell, Wallet, User, TrendingUp } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

export function MarketplaceHeader() {
  return (
    <header className="bg-white border-b border-gray-200 px-6 py-4">
      <div className="flex items-center justify-between">
        {/* Logo & Navigation */}
        <div className="flex items-center space-x-8">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-blue-500 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-sm">AI</span>
            </div>
            <span className="text-xl font-bold">NFT Nexus</span>
          </div>

          <nav className="flex items-center space-x-6">
            <Button variant="ghost" className="font-medium">
              EXPLORE
            </Button>
            <Button variant="ghost" className="font-medium">
              COLLECTIONS
            </Button>
            <Button variant="ghost" className="font-medium">
              AI AGENTS
            </Button>
            <Button variant="ghost" className="font-medium">
              ANALYTICS
            </Button>
          </nav>
        </div>

        {/* Search & Actions */}
        <div className="flex items-center space-x-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input placeholder="Search NFTs, collections, creators..." className="pl-10 w-80" />
          </div>

          <Button variant="outline" size="icon" className="relative bg-transparent">
            <Bell className="w-4 h-4" />
            <Badge className="absolute -top-2 -right-2 w-5 h-5 p-0 flex items-center justify-center text-xs">3</Badge>
          </Button>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" className="flex items-center space-x-2 bg-transparent">
                <Wallet className="w-4 h-4" />
                <span>0x1234...5678</span>
                <Badge variant="secondary" className="ml-2">
                  12.5 ETH
                </Badge>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem>
                <User className="w-4 h-4 mr-2" />
                Profile
              </DropdownMenuItem>
              <DropdownMenuItem>
                <TrendingUp className="w-4 h-4 mr-2" />
                Portfolio
              </DropdownMenuItem>
              <DropdownMenuItem>
                <Wallet className="w-4 h-4 mr-2" />
                Disconnect Wallet
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  )
}
